/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DangDinhSiQLSV;

import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class MainThread {

    public static void main(String[] args) {
        StudentModel st = new StudentModel();
        Scanner input = new Scanner(System.in);
        int luachon;
        int i=0;
        while (i==0) {            
        System.out.println("***************QUẢN LÝ SINH VIÊN***************");
        System.out.println("1.Danh sách sinh viên.");
        System.out.println("2.Thêm sinh viên.");
        System.out.println("3.Update thông tin sinh viên.");
        System.out.println("4.Xóa sinh viên.");
        System.out.println("5.Tra cứu thông tin.");
        System.out.println("6.Thoát.");
        System.out.println("_______________________________________________");
        System.out.println("                                               ");
        System.out.print("Nhập lựa chọn: ");
        luachon = Integer.parseInt(input.nextLine());
        switch(luachon){
            case 1:
                System.out.println("Danh sách sinh viên");
                st.listStudent();
                break;
            case 2:
                st.addStudent();
                break;
            case 3:
                st.listStudent();
                while(true){
                System.out.print("Nhập roll number: ");
                String rollnumber = input.nextLine();
                if(!st.checkRollNumber(rollnumber)){
                    st.updateStudent(rollnumber);
                    st.listStudent();
                    break;
                }
                    System.out.println("Vui lòng nhập đúng roll number!");
                }
                break;
            case 4:
                st.listStudent();
                while(true){
                System.out.print("Nhập roll number sinh viên cần xóa: ");
                String rollNumber = input.nextLine();
                if(!st.checkRollNumber(rollNumber)){
                    st.deleteStudent(rollNumber);
                    st.listStudent();
                    break;
                }
                    System.out.println("Vui lòng nhập đúng roll number!");
                }
                break;
            case 5:
                st.listStudent();
                while (true) {                    
                System.out.print("Nhập roll number cần tra cứu: ");
                String roll = input.nextLine();
                if(!st.checkRollNumber(roll)){
                   st.getdetailStudent(roll);
                   break;
                }
                System.out.println("Không tồn tại roll number này");
                }
                break;
                
            case 6:
                i=1;
                break;
            default:
                System.out.println("Vui lòng lựa chọn từ 1-5!");
                break;
        }
        }

    }
}
