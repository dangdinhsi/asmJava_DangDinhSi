/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DangDinhSiQLSV;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Admin
 */
public class DBconnection {
    Connection conn = null;
    public Connection ketnoi(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            System.out.println("Không thể load driver!");
        }
        try {
            conn =DriverManager.getConnection("jdbc:mysql://localhost:3306/si_qlsv","root","");
        } catch (SQLException ex) {
            System.out.println("Không kết nối được với database");
        }
        return conn;
    }
}
