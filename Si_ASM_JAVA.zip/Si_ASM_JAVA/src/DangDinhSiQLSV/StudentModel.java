/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DangDinhSiQLSV;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class StudentModel {

    DBconnection kn = new DBconnection();
    Connection conn = null;
    PreparedStatement pst = null;
    Student st = new Student();

    //1.Thêm sinh viên vào database.
    public void addStudent() {
        conn = kn.ketnoi();
        Scanner input = new Scanner(System.in);
        String name,phone,email,rollNumber;
        int status;
        while (true) {
            // Yêu cầu người dùng nhập.
            System.out.println("Nhập name: ");
            // Lấy giá trị người dùng nhập vào để gán cho biến.
            name = input.nextLine();

            if (name != null && name.length() > 5) {                
                st.setName(name);
                break;
            }
            System.out.println("Tên không hợp lệ!");
        }
        while (true) {            
            System.out.print("Nhập roll number: ");
        rollNumber = input.nextLine();
        if(checkRollNumber(rollNumber)){
            st.setRollNumber(rollNumber);
            break;
        }
            System.out.println("Roll number đã tồn tại!");
        }
        
        while (true) {
            System.out.println("Nhập phone: ");
            phone = input.nextLine();
            if (phone != null && phone.length() > 5) {                
                st.setPhone(phone);
                break;
            }
            System.out.println("Phone không hợp lệ!");
            }
            
            while (true) {
            System.out.println("Nhập email: ");
            email = input.nextLine();
            if (email != null && email.length() > 5) {                
                st.setEmail(email);
                break;
            }
            System.out.println("Email không hợp lệ!");
        }
            
            while(true){
                System.out.println("Nhập status: ");
                status = Integer.parseInt(input.nextLine());
                if(status==1){
                    st.setStatus(status);
                    break;
                }else if(status==0){
                    st.setStatus(status);
                    break;
                }
                else{
                    System.out.println("Status không hợp lệ!");
                }
            }
        String sql = "INSERT INTO student(name,rollNumber,phone,email,status) values(?,?,?,?,?)";
        try {
            pst = conn.prepareStatement(sql);
            pst.setString(1, name);
            pst.setString(2, rollNumber);
            pst.setString(3, phone);
            pst.setString(4, email);
            pst.setInt(5, status);
            pst.executeUpdate();
            System.out.println("Thêm thành công sinh viên vào danh sách");
        } catch (SQLException ex) {
            System.out.println("Xuất hiện lỗi khi thêm sinh viên vào danh sách: " + ex.getMessage());
        } 
        
        
    }

    //2.Hiển thị danh sách sinh viên.
    public void listStudent() {
        conn = kn.ketnoi();
        String sql = "select * from student";
        try {
            pst = conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            System.out.printf("\n\t%-10s %-20s %-20s %-20s %-30s %-10s\n","ID","NAME","ROLL NUMBER","PHONE","EMAIL","STATUS");
            while (rs.next()) {               
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String rollNumber = rs.getString("rollNumber");
                String phone = rs.getString("phone");
                String email = rs.getString("email");
                int status = rs.getInt("status");
                System.out.printf("\n\t%-10d %-20s %-20s %-20s %-30s %-10d\n", id, name, rollNumber,phone,email,status);

            }
        } catch (SQLException ex) {
            System.out.println("Xuất hiện lỗi: " + ex.getMessage());
        }
    }

    //3.Xóa sinh viên theo mã sinh viên.
    public void deleteStudent(String rollNumber) {
        Scanner input = new Scanner(System.in);
        conn = kn.ketnoi();
       
        String sql = "delete from student where rollNumber = ?";
        try {
            pst = conn.prepareStatement(sql);
            pst.setString(1, rollNumber);
            pst.executeUpdate();
            System.out.println("Xóa thành công!");
        } catch (SQLException ex) {
            System.out.println("Xuất hiện lỗi: " + ex.getMessage());
        }
    }

    //4.Cập nhật sinh viên theo mã sinh viên.
    public void updateStudent(String rollNumber) {
        conn = kn.ketnoi();
        Scanner input = new Scanner(System.in);
        String newRollNumber,name,phone,email;
        int status;
        System.out.print("Cập nhật rollNumber: ");
        newRollNumber = input.nextLine();
          while (true) {
            // Yêu cầu người dùng nhập.
            System.out.println("Cập nhật name: ");
            // Lấy giá trị người dùng nhập vào để gán cho biến.
            name = input.nextLine();

            if (name != null && name.length() > 5) {                
                st.setName(name);
                break;
            }
            System.out.println("Tên không hợp lệ!");
        }
          while (true) {
            System.out.println("Nhập phone: ");
            phone = input.nextLine();
            if (phone != null && phone.length() > 5) {                
                st.setPhone(phone);
                break;
            }
            System.out.println("Phone không hợp lệ!");
            }
              while (true) {
            System.out.println("Nhập email: ");
            email = input.nextLine();
            if (email != null && email.length() > 5) {                
                st.setEmail(email);
                break;
            }
            System.out.println("Email không hợp lệ!");
        }
                 while(true){
                System.out.println("Nhập status: ");
                status = Integer.parseInt(input.nextLine());
                if(status==1){
                    st.setStatus(status);
                    break;
                }else if(status==0){
                    st.setStatus(status);
                    break;
                }
                else{
                    System.out.println("Status không hợp lệ!");
                }
            }
        String sql = "update student set rollNumber =?,name =?,phone =?,email =?,status=? where rollNumber = ?";

        try {
            pst = conn.prepareStatement(sql);
            pst.setString(1, newRollNumber);
            pst.setString(2, name);
            pst.setString(3, phone);
            pst.setString(4, email);
            pst.setInt(5, status);
            pst.setString(6, rollNumber);
            pst.executeUpdate();
            System.out.println("Update thông tin thành công!");
            
        } catch (SQLException ex) {
            System.out.println("Xuất hiện lỗi trong quá trình update: " + ex.getMessage());
        }

    }

    //5.Lấy thông tin của sinh viên cụ thể theo mã sinh viên.
    public void getdetailStudent(String roll) {
        conn = kn.ketnoi();
        String sql = "select * from student where rollNumber=?";
        try {
            pst = conn.prepareStatement(sql);
            pst.setString(1, roll);
            ResultSet rs = pst.executeQuery();
            while(rs.next()){
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String rollnumber = rs.getString("rollNumber");
                String phone = rs.getString("phone");
                String email = rs.getString("email");
                int status = rs.getInt("status");
                System.out.println("ID: "+id);
                System.out.println("Tên: "+name);
                System.out.println("Roll number: "+rollnumber);
                System.out.println("Phone: "+ phone);
                System.out.println("Email: "+email);
                System.out.println("Status: "+status);
            }
        } catch (SQLException ex) {
            System.out.println("Roll number này không hợp lệ!");
        }
        
    }
    
    public boolean checkRollNumber(String rollNumber){
        conn = kn.ketnoi();
        String sql ="select rollNumber from student";
        boolean check = true;
        try {
            pst= conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {                
                String rollkiemtra = rs.getString("rollNumber");
                if(rollkiemtra.equals(rollNumber)){
                    check = false;
                }
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        
        return check;
        
    }
}
